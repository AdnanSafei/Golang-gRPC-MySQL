package model

type UserDB struct {
	Id       int `gorm:"primary_key; auto_increment; not_null"` //primarykey field
	Name     string //field1
	Email    string //field2
	Alamat   string //field3
	Password string //field4
}

func (e *UserDB) TableName() string {
	return "user" //nama tabel
}
