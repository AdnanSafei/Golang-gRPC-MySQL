package main

import (
	"fmt"
	"grpc-server/model"
	userHandler "grpc-server/user/handler"
	userRepo "grpc-server/user/repo"
	userUsecase "grpc-server/user/usecase"
	"log"
	"net"

	_ "github.com/go-sql-driver/mysql"
	"github.com/jinzhu/gorm"
	"google.golang.org/grpc"
)

func main() {
	var port = "8957"
	fmt.Println("Connecting to database...")
	consStr := "root:safei123@tcp(127.0.0.1)/infran?parseTime=true"
	//consStr := "biometric:biometric@2019@tcp(basisdata.grit.id)/biometric?parseTime=true"
	db, err := gorm.Open("mysql", consStr)
	if err != nil {
		log.Fatal(err)
	}

	db.Debug().AutoMigrate(
		model.UserDB{},
	)

	server := grpc.NewServer()

	userRepo := userRepo.CreateUserRepoImpl(db)
	userUsecase := userUsecase.CreateUserUsecase(userRepo)

	userHandler.CreateUserHandler(server, userUsecase)

	conn, err := net.Listen("tcp", ":"+port)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Server Starting at Port: ", port)
	log.Fatal(server.Serve(conn))
}
